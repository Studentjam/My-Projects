import { memo, SVGProps } from 'react';

const Qowz3suvutbrb0mrIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 189 37' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M18.1865 2.00009e-07H170.263C180.299 2.00009e-07 188.435 8.135 188.435 18.17C188.435 28.2051 180.299 36.3401 170.263 36.3401H18.1865C8.15056 36.3401 0.014835 28.2051 0.014835 18.17C0.014835 8.135 8.15056 2.00009e-07 18.1865 2.00009e-07Z'
      fill='#E6CF57'
    />
  </svg>
);

const Memo = memo(Qowz3suvutbrb0mrIcon);
export { Memo as Qowz3suvutbrb0mrIcon };
