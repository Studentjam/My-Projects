import { memo, SVGProps } from 'react';

const _5c489e2d8151c135beaccab8d666a6 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 2025 1139' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_112_233)'>
      <path
        fillRule='evenodd'
        clipRule='evenodd'
        d='M0 0.2675H2024.08V1138.81H0V0.2675Z'
        fill='url(#paint0_linear_112_233)'
      />
    </g>
    <defs>
      <linearGradient
        id='paint0_linear_112_233'
        x1={0}
        y1={0.2675}
        x2={97300}
        y2={172978}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#235A86' />
        <stop offset={1} stopColor='#071332' />
      </linearGradient>
      <clipPath id='clip0_112_233'>
        <rect width={2024.08} height={1138.55} fill='white' transform='translate(0 0.2675)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(_5c489e2d8151c135beaccab8d666a6);
export { Memo as _5c489e2d8151c135beaccab8d666a6 };
