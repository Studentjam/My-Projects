import { memo, SVGProps } from 'react';

const Ysyge5el3mn8zbnzIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 552 152' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0H551.94V151.69H0V0Z' fill='white' />
  </svg>
);

const Memo = memo(Ysyge5el3mn8zbnzIcon);
export { Memo as Ysyge5el3mn8zbnzIcon };
