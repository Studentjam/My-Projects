import { memo, SVGProps } from 'react';

const B80qaqtovfzsm2nbIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 456 357' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0H455.3V356.78H0V0Z' fill='#0A1A44' />
  </svg>
);

const Memo = memo(B80qaqtovfzsm2nbIcon);
export { Memo as B80qaqtovfzsm2nbIcon };
