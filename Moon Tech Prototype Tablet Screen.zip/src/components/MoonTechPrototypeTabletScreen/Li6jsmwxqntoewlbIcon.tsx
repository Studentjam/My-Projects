import { memo, SVGProps } from 'react';

const Li6jsmwxqntoewlbIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 456 384' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0H455.31V383.81H0V0Z' fill='#071332' />
  </svg>
);

const Memo = memo(Li6jsmwxqntoewlbIcon);
export { Memo as Li6jsmwxqntoewlbIcon };
