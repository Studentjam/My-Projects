import { memo, SVGProps } from 'react';

const _30b3c7c5f87a51c92f18ba80d553632 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 31 25' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_112_240)'>
      <path
        d='M0 14.301C0 5.53322 4.54963 0.983585 13.3175 0.983585V7.29582C9.80731 7.29582 7.50237 8.77219 6.65873 11.499H13.3175V24.8164H0V14.301ZM16.8125 14.301C16.8125 5.53322 21.3772 0.983585 30.13 0.983585V7.29582C26.6199 7.29582 24.3149 8.77219 23.4713 11.499H30.13V24.8164H16.8125V14.301Z'
        fill='white'
      />
    </g>
    <defs>
      <clipPath id='clip0_112_240'>
        <rect width={30.13} height={23.8328} fill='white' transform='translate(0 0.983585)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(_30b3c7c5f87a51c92f18ba80d553632);
export { Memo as _30b3c7c5f87a51c92f18ba80d553632 };
