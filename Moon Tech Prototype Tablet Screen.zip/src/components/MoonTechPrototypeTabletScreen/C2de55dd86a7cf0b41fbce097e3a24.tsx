import { memo, SVGProps } from 'react';

const C2de55dd86a7cf0b41fbce097e3a24 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 955 538' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_112_200)'>
      <path
        fillRule='evenodd'
        clipRule='evenodd'
        d='M0 0.680625H954.22V537.429H0V0.680625Z'
        fill='url(#paint0_linear_112_200)'
      />
    </g>
    <defs>
      <linearGradient
        id='paint0_linear_112_200'
        x1={0}
        y1={0.680625}
        x2={45870.5}
        y2={81548.3}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#235A86' />
        <stop offset={1} />
      </linearGradient>
      <clipPath id='clip0_112_200'>
        <rect width={954.22} height={536.749} fill='white' transform='translate(0 0.680625)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(C2de55dd86a7cf0b41fbce097e3a24);
export { Memo as C2de55dd86a7cf0b41fbce097e3a24 };
