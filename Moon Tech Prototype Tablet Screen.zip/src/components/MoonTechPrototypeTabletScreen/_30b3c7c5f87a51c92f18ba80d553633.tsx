import { memo, SVGProps } from 'react';

const _30b3c7c5f87a51c92f18ba80d553633 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 31 25' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_112_246)'>
      <path
        d='M0 14.3015C0 5.53077 4.55114 0.97963 13.3219 0.97963V7.29396C9.81057 7.29396 7.50486 8.77082 6.66094 11.4985H13.3219V24.8204H0V14.3015ZM16.8181 14.3015C16.8181 5.53077 21.3843 0.97963 30.14 0.97963V7.29396C26.6287 7.29396 24.323 8.77082 23.4791 11.4985H30.14V24.8204H16.8181V14.3015Z'
        fill='white'
      />
    </g>
    <defs>
      <clipPath id='clip0_112_246'>
        <rect width={30.14} height={23.8407} fill='white' transform='translate(0 0.97963)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(_30b3c7c5f87a51c92f18ba80d553633);
export { Memo as _30b3c7c5f87a51c92f18ba80d553633 };
