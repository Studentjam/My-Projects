import { memo, SVGProps } from 'react';

const Oyr2iol42ul83ygfIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 49 49' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M24.045 0C10.7653 0 0 10.7743 0 24.065C0 37.3557 10.7653 48.13 24.045 48.13C37.3247 48.13 48.09 37.3557 48.09 24.065C48.09 10.7743 37.3247 0 24.045 0Z'
      fill='#E6CF57'
    />
  </svg>
);

const Memo = memo(Oyr2iol42ul83ygfIcon);
export { Memo as Oyr2iol42ul83ygfIcon };
