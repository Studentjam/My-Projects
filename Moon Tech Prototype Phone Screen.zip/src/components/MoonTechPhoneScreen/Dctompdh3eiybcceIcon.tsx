import { memo, SVGProps } from 'react';

const Dctompdh3eiybcceIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 364 341' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0H363.97V340.05H0V0Z' fill='#0A1A44' />
  </svg>
);

const Memo = memo(Dctompdh3eiybcceIcon);
export { Memo as Dctompdh3eiybcceIcon };
