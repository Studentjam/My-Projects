import { memo, SVGProps } from 'react';

const _5c489e2d8151c135beaccab8d666a6 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1568 883' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_112_321)'>
      <path
        fillRule='evenodd'
        clipRule='evenodd'
        d='M0 0.4125H1567.92V882.368H0V0.4125Z'
        fill='url(#paint0_linear_112_321)'
      />
    </g>
    <defs>
      <linearGradient
        id='paint0_linear_112_321'
        x1={0}
        y1={0.4125}
        x2={75371.8}
        y2={133995}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#235A86' />
        <stop offset={1} stopColor='#071332' />
      </linearGradient>
      <clipPath id='clip0_112_321'>
        <rect width={1567.92} height={881.955} fill='white' transform='translate(0 0.4125)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(_5c489e2d8151c135beaccab8d666a6);
export { Memo as _5c489e2d8151c135beaccab8d666a6 };
