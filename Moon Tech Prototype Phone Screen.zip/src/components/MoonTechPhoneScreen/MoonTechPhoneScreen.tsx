import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { _5c489e2d8151c135beaccab8d666a6 } from './_5c489e2d8151c135beaccab8d666a6.js';
import { _13f68cc073c04971e2acac869f3ea0 } from './_13f68cc073c04971e2acac869f3ea0.js';
import { _30b3c7c5f87a51c92f18ba80d55363 } from './_30b3c7c5f87a51c92f18ba80d55363.js';
import { _30b3c7c5f87a51c92f18ba80d553632 } from './_30b3c7c5f87a51c92f18ba80d553632.js';
import { _30b3c7c5f87a51c92f18ba80d553633 } from './_30b3c7c5f87a51c92f18ba80d553633.js';
import { _30b3c7c5f87a51c92f18ba80d553634 } from './_30b3c7c5f87a51c92f18ba80d553634.js';
import { _85e1818a3598c721bb9e7b53832406 } from './_85e1818a3598c721bb9e7b53832406.js';
import { A0ce3353befb16cec7fac33d16050d } from './A0ce3353befb16cec7fac33d16050d.js';
import { Bixakrpqf6az1satIcon } from './Bixakrpqf6az1satIcon.js';
import { C2de55dd86a7cf0b41fbce097e3a24 } from './C2de55dd86a7cf0b41fbce097e3a24.js';
import { D6yp1ieeckgnykfhIcon } from './D6yp1ieeckgnykfhIcon.js';
import { Darmmt8xebsbmk50Icon } from './Darmmt8xebsbmk50Icon.js';
import { Dctompdh3eiybcceIcon } from './Dctompdh3eiybcceIcon.js';
import { Ellipse7Icon2 } from './Ellipse7Icon2.js';
import { Ellipse7Icon3 } from './Ellipse7Icon3.js';
import { Ellipse7Icon } from './Ellipse7Icon.js';
import { F86433c397efa39b3352a427849f2e } from './F86433c397efa39b3352a427849f2e.js';
import { Fzwkq74mgsnkjjlsIcon } from './Fzwkq74mgsnkjjlsIcon.js';
import classes from './MoonTechPhoneScreen.module.css';
import { Oev4ayqxspkvuub0Icon } from './Oev4ayqxspkvuub0Icon.js';
import { Oyr2iol42ul83ygfIcon } from './Oyr2iol42ul83ygfIcon.js';
import { Qowz3suvutbrb0mrIcon } from './Qowz3suvutbrb0mrIcon.js';
import { Sca3bjmwvhkiqnpvIcon } from './Sca3bjmwvhkiqnpvIcon.js';
import { SvgIcon2 } from './SvgIcon2.js';
import { SvgIcon } from './SvgIcon.js';
import { Ucihicerihoian5sIcon } from './Ucihicerihoian5sIcon.js';
import { Vmlq8wmkcn0kzqepIcon } from './Vmlq8wmkcn0kzqepIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 102:1085 */
export const MoonTechPhoneScreen: FC<Props> = memo(function MoonTechPhoneScreen(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.container}>
        <div className={classes.section}>
          <div className={classes.container2}>
            <div className={classes.background}></div>
            <div className={classes.margin}>
              <div className={classes.maskGroup}>
                <div className={classes.container3}>
                  <div className={classes.container4}>
                    <div className={classes.c2de55dd86a7cf0b41fbce097e3a24}>
                      <div className={classes.c2de55dd86a7cf0b41fbce097e3a242}>
                        <div className={classes.c2de55dd86a7cf0b41fbce097e3a243}>
                          <C2de55dd86a7cf0b41fbce097e3a24 className={classes.icon} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={classes.container5}>
            <div className={classes.container6}></div>
            <div className={classes.container7}>
              <div className={classes.container8}>
                <div className={classes.container9}>
                  <div className={classes.sVG}>
                    <div className={classes.qowz3sUvuTbrB0mr}>
                      <Qowz3suvutbrb0mrIcon className={classes.icon2} />
                    </div>
                  </div>
                </div>
                <div className={classes.container10}>
                  <div className={classes.container11}>
                    <div className={classes.container12}>
                      <div className={classes.contactUs}>Contact Us</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container13}></div>
            <div className={classes.container14}>
              <div className={classes.container15}>
                <div className={classes.container16}>
                  <div className={classes.f86433c397efa39b3352a427849f2e}>
                    <div className={classes.f86433c397efa39b3352a427849f2e2}>
                      <div className={classes.f86433c397efa39b3352a427849f2e3}>
                        <F86433c397efa39b3352a427849f2e className={classes.icon3} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container17}>
              <div className={classes.container18}>
                <div className={classes.container19}>
                  <div className={classes.getTheLatestDesigns}>
                    <div className={classes.textBlock}>Get the latest</div>
                    <div className={classes.textBlock2}>Designs!</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container20}>
              <div className={classes.container21}>
                <div className={classes.container22}>
                  <div className={classes.moonTech}>Moon Tech</div>
                </div>
              </div>
            </div>
            <div className={classes.loremIpsumDolorSitAmetConsecte}>
              <div className={classes.textBlock3}>Lorem ipsum dolor sit </div>
              <div className={classes.textBlock4}>amet, consectetur</div>
              <div className={classes.textBlock5}>adipiscing elit. Vivamus luctus</div>
              <div className={classes.textBlock6}> urna sed urna</div>
              <div className={classes.textBlock7}>ultricies ac tempor dui sagittis. In</div>
              <div className={classes.textBlock8}>condimentum facilisis porta. </div>
            </div>
            <div className={classes.rectangle6}></div>
            <div className={classes.rectangle9}></div>
            <div className={classes.top}></div>
            <div className={classes.middle}></div>
            <div className={classes.last}></div>
          </div>
        </div>
        <div className={classes.section2}>
          <div className={classes.container23}>
            <div className={classes.background2}></div>
          </div>
          <div className={classes.container24}>
            <div className={classes.container25}>
              <div className={classes.sVG2}>
                <div className={classes.rectangle7}></div>
              </div>
            </div>
            <div className={classes.container26}>
              <div className={classes.container27}>
                <div className={classes.container28}>
                  <div className={classes.weHireTheTopWebDesigners}>
                    <div className={classes.textBlock9}>We Hire the top</div>
                    <div className={classes.textBlock10}>Web Designers</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container29}>
              <div className={classes.container30}>
                <div className={classes.container31}>
                  <div className={classes.loremIpsumDolorSitAmetConsecte2}>
                    <div className={classes.textBlock11}>Lorem ipsum dolor sit amet, consectetur</div>
                    <div className={classes.textBlock12}>adipiscing elit. Vivamus luctus urna sed urna</div>
                    <div className={classes.textBlock13}>ultricies ac tempor dui sagittis. In</div>
                    <div className={classes.textBlock14}>condimentum facilisis porta. Sed nec diam eu</div>
                    <div className={classes.textBlock15}>diam mattis viverra. Nulla fringilla, orci ac</div>
                    <div className={classes.textBlock16}>euismod semper, magna diam porttitor</div>
                    <div className={classes.textBlock17}>mauris, quis sollicitudin sapien justo in libero.</div>
                    <div className={classes.textBlock18}>Vestibulum mollis mauris enim.</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={classes.section3}>
          <div className={classes.container32}>
            <div className={classes.background3}></div>
          </div>
          <div className={classes.container33}>
            <div className={classes.container34}>
              <div className={classes.container35}>
                <div className={classes.container36}>
                  <div className={classes.container37}>
                    <div className={classes.sVG3}>
                      <div className={classes.bIxaKRpQF6AZ1sAt}>
                        <Bixakrpqf6az1satIcon className={classes.icon4} />
                      </div>
                    </div>
                  </div>
                  <div className={classes.container38}>
                    <div className={classes.container39}>
                      <div className={classes.container40}>
                        <div className={classes._1}>1</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={classes.margin2}>
                  <div className={classes.maskGroup2}>
                    <div className={classes.container41}>
                      <div className={classes.sVG4}>
                        <div className={classes.qnqdNaHtRzwlP0Bm}>
                          <div className={classes.oeV4aYQxspKVUUb0}>
                            <Oev4ayqxspkvuub0Icon className={classes.icon5} />
                          </div>
                          <div className={classes.ellipse7}>
                            <Ellipse7Icon className={classes.icon6} />
                          </div>
                          <div className={classes._12}>1</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={classes.container42}>
                  <div className={classes.container43}>
                    <div className={classes.container44}>
                      <div className={classes.loremIpsumDolorSitAmetConsecte3}>
                        <div className={classes.textBlock19}>Lorem ipsum dolor sit amet, consectetur</div>
                        <div className={classes.textBlock20}>adipiscing elit. Vivamus luctus urna sed</div>
                        <div className={classes.textBlock21}>urna ultricies ac tempor dui sagittis.</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container45}>
              <div className={classes.container46}>
                <div className={classes.container47}>
                  <div className={classes.container48}>
                    <div className={classes.sVG5}>
                      <div className={classes.vmlq8WmKCN0kZqEP}>
                        <Vmlq8wmkcn0kzqepIcon className={classes.icon7} />
                      </div>
                    </div>
                  </div>
                  <div className={classes.container49}>
                    <div className={classes.container50}>
                      <div className={classes.container51}>
                        <div className={classes._2}>2</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={classes.margin3}>
                  <div className={classes.maskGroup3}>
                    <div className={classes.container52}>
                      <div className={classes.sVG6}>
                        <div className={classes.fHd3Sp5GjXKnvWxm}>
                          <div className={classes.d6yp1iEECKgnykFH}>
                            <D6yp1ieeckgnykfhIcon className={classes.icon8} />
                          </div>
                          <div className={classes.ellipse72}>
                            <Ellipse7Icon2 className={classes.icon9} />
                          </div>
                          <div className={classes._22}>2</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={classes.container53}>
                  <div className={classes.container54}>
                    <div className={classes.container55}>
                      <div className={classes.loremIpsumDolorSitAmetConsecte4}>
                        <div className={classes.textBlock22}>Lorem ipsum dolor sit amet,</div>
                        <div className={classes.textBlock23}>consectetur adipiscing elit.</div>
                        <div className={classes.textBlock24}>Vivamus luctus urna sed urna</div>
                        <div className={classes.textBlock25}>ultricies ac tempor dui sagittis. In</div>
                        <div className={classes.textBlock26}>condimentum facilisis porta</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container56}>
              <div className={classes.container57}>
                <div className={classes.container58}>
                  <div className={classes.container59}>
                    <div className={classes.sVG7}>
                      <div className={classes.oYr2IoL42ul83YgF}>
                        <Oyr2iol42ul83ygfIcon className={classes.icon10} />
                      </div>
                    </div>
                  </div>
                  <div className={classes.container60}>
                    <div className={classes.container61}>
                      <div className={classes.container62}>
                        <div className={classes._3}>3</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={classes.margin4}>
                  <div className={classes.maskGroup4}>
                    <div className={classes.container63}>
                      <div className={classes.sVG8}>
                        <div className={classes.jfsw2P5UIUcCDNjp}>
                          <div className={classes.dCtOmpDh3eiYBccE}>
                            <Dctompdh3eiybcceIcon className={classes.icon11} />
                          </div>
                          <div className={classes.ellipse73}>
                            <Ellipse7Icon3 className={classes.icon12} />
                          </div>
                          <div className={classes._32}>3</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={classes.container64}>
                  <div className={classes.container65}>
                    <div className={classes.container66}>
                      <div className={classes.loremIpsumDolorSitAmetConsecte5}>
                        <div className={classes.textBlock27}>Lorem ipsum dolor sit amet,</div>
                        <div className={classes.textBlock28}>consectetur adipiscing elit.</div>
                        <div className={classes.textBlock29}>Vivamus luctus urna sed urna</div>
                        <div className={classes.textBlock30}>ultricies ac tempor dui sagittis.</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container67}>
              <div className={classes.container68}>
                <div className={classes.container69}>
                  <div className={classes.learnMoreAboutUs}>
                    <div className={classes.textBlock31}>Learn more</div>
                    <div className={classes.textBlock32}>about us</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={classes.section4}>
          <div className={classes.container70}>
            <div className={classes.background4}></div>
            <div className={classes.margin5}>
              <div className={classes.maskGroup5}>
                <div className={classes.container71}>
                  <div className={classes.container72}>
                    <div className={classes._5c489e2d8151c135beaccab8d666a6}>
                      <div className={classes._5c489e2d8151c135beaccab8d666a62}>
                        <div className={classes._5c489e2d8151c135beaccab8d666a63}>
                          <_5c489e2d8151c135beaccab8d666a6 className={classes.icon13} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={classes.container73}>
            <div className={classes.container74}>
              <div className={classes.container75}>
                <div className={classes.container76}>
                  <div className={classes.container77}>
                    <div className={classes.container78}>
                      <div className={classes._30b3c7c5f87a51c92f18ba80d55363}>
                        <div className={classes._30b3c7c5f87a51c92f18ba80d553632}>
                          <div className={classes._30b3c7c5f87a51c92f18ba80d553633}>
                            <_30b3c7c5f87a51c92f18ba80d55363 className={classes.icon14} />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container79}>
              <div className={classes.container80}>
                <div className={classes.container81}>
                  <div className={classes.container82}>
                    <div className={classes.container83}>
                      <div className={classes._30b3c7c5f87a51c92f18ba80d553634}>
                        <div className={classes._30b3c7c5f87a51c92f18ba80d553635}>
                          <div className={classes._30b3c7c5f87a51c92f18ba80d553636}>
                            <_30b3c7c5f87a51c92f18ba80d553632 className={classes.icon15} />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container84}>
              <div className={classes.container85}>
                <div className={classes.sVG9}>
                  <SvgIcon className={classes.icon16} />
                </div>
              </div>
            </div>
            <div className={classes.container86}>
              <div className={classes.container87}>
                <div className={classes.container88}>
                  <div className={classes.loremIpsumDolorSitAmetConsecte6}>
                    <div className={classes.textBlock33}>Lorem ipsum dolor sit amet, consectetur</div>
                    <div className={classes.textBlock34}>adipiscing elit. Vivamus luctus urna sed</div>
                    <div className={classes.textBlock35}>urna ultricies ac tempor dui sagittis. In</div>
                    <div className={classes.textBlock36}>condimentum facilisis porta. Sed nec</div>
                    <div className={classes.textBlock37}>diam eu diam mattis viverra.</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container89}>
              <div className={classes.container90}>
                <div className={classes.container91}>
                  <div className={classes.iLoremIpsumDolorSitAmetConsect}>
                    <div className={classes.textBlock38}>ILorem ipsum dolor sit amet, consectetur</div>
                    <div className={classes.textBlock39}>adipiscing elit. Vivamus luctus urna sed</div>
                    <div className={classes.textBlock40}>urna ultricies ac tempor dui sagittis. In</div>
                    <div className={classes.textBlock41}>condimentum facilisis porta. Sed nec diam</div>
                    <div className={classes.textBlock42}>eu diam mattis viverra. Nulla fringilla.</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container92}>
              <div className={classes.container93}>
                <div className={classes.container94}>
                  <div className={classes.container95}>
                    <div className={classes.container96}>
                      <div className={classes._30b3c7c5f87a51c92f18ba80d553637}>
                        <div className={classes._30b3c7c5f87a51c92f18ba80d553638}>
                          <div className={classes._30b3c7c5f87a51c92f18ba80d553639}>
                            <_30b3c7c5f87a51c92f18ba80d553633 className={classes.icon17} />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container97}>
              <div className={classes.container98}>
                <div className={classes.container99}>
                  <div className={classes.container100}>
                    <div className={classes.container101}>
                      <div className={classes._30b3c7c5f87a51c92f18ba80d5536310}>
                        <div className={classes._30b3c7c5f87a51c92f18ba80d5536311}>
                          <div className={classes._30b3c7c5f87a51c92f18ba80d5536312}>
                            <_30b3c7c5f87a51c92f18ba80d553634 className={classes.icon18} />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container102}>
              <div className={classes.container103}>
                <div className={classes.sVG10}>
                  <SvgIcon2 className={classes.icon19} />
                </div>
              </div>
            </div>
            <div className={classes.container104}>
              <div className={classes.container105}>
                <div className={classes.container106}>
                  <div className={classes.ingridRichards}>Ingrid Richards</div>
                </div>
                <div className={classes.container107}>
                  <div className={classes.cEOOfGreenLakes}>CEO of Green Lakes</div>
                </div>
              </div>
            </div>
            <div className={classes.container108}>
              <div className={classes.container109}>
                <div className={classes.container110}>
                  <div className={classes.daveHanda}>Dave Handa</div>
                </div>
                <div className={classes.container111}>
                  <div className={classes.cEOOfPureGolf}>CEO of Pure Golf</div>
                </div>
              </div>
            </div>
            <div className={classes.container112}>
              <div className={classes.container113}>
                <div className={classes.container114}>
                  <div className={classes.readOurReviews}>Read Our Reviews</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={classes.section5}>
          <div className={classes.container115}>
            <div className={classes.background5}></div>
          </div>
          <div className={classes.container116}>
            <div className={classes.container117}>
              <div className={classes.sVG11}>
                <div className={classes.rectangle8}></div>
              </div>
            </div>
            <div className={classes.container118}>
              <div className={classes.container119}>
                <div className={classes.container120}>
                  <div className={classes.getting}>Getting</div>
                </div>
                <div className={classes.container121}>
                  <div className={classes.startedWithUs}>
                    <div className={classes.textBlock43}>Started with</div>
                    <div className={classes.textBlock44}>us</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container122}>
              <div className={classes.container123}>
                <div className={classes.container124}>
                  <div className={classes.loremIpsumDolorSitAmetConsecte7}>
                    <div className={classes.textBlock45}>Lorem ipsum dolor sit amet, consectetur</div>
                    <div className={classes.textBlock46}>adipiscing elit. Vivamus luctus urna sed urna</div>
                    <div className={classes.textBlock47}>ultricies ac tempor dui sagittis. In</div>
                    <div className={classes.textBlock48}>condimentum facilisis porta. Sed nec diam</div>
                    <div className={classes.textBlock49}>eu diam mattis viverra. Nulla fringilla, orci ac</div>
                    <div className={classes.textBlock50}>euismod semper, magna diam porttitor</div>
                    <div className={classes.textBlock51}>mauris, quis sollicitudin sapien justo in</div>
                    <div className={classes.textBlock52}>libero.</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={classes.section6}>
          <div className={classes.container125}>
            <div className={classes.background6}></div>
          </div>
          <div className={classes.container126}>
            <div className={classes.container127}>
              <div className={classes.container128}>
                <div className={classes.container129}>
                  <div className={classes.container130}>
                    <div className={classes.sVG12}>
                      <div className={classes.daRMMt8XeBsbmK50}>
                        <Darmmt8xebsbmk50Icon className={classes.icon20} />
                      </div>
                    </div>
                  </div>
                  <div className={classes.container131}>
                    <div className={classes.container132}>
                      <div className={classes.container133}>
                        <div className={classes.contactUs2}>Contact Us</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container134}>
              <div className={classes.container135}>
                <div className={classes.container136}>
                  <div className={classes.sVG13}>
                    <div className={classes.fZWkQ74MgSnkjjLs}>
                      <Fzwkq74mgsnkjjlsIcon className={classes.icon21} />
                    </div>
                  </div>
                </div>
                <div className={classes.container137}>
                  <div className={classes.container138}>
                    <div className={classes.container139}>
                      <div className={classes.fullName}>Full Name</div>
                    </div>
                  </div>
                </div>
                <div className={classes.container140}>
                  <div className={classes.container141}>
                    <div className={classes.container142}>
                      <div className={classes.name}>Name :</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container143}>
              <div className={classes.container144}>
                <div className={classes.container145}>
                  <div className={classes.sVG14}>
                    <div className={classes.sCa3bJMWVHKIqNPV}>
                      <Sca3bjmwvhkiqnpvIcon className={classes.icon22} />
                    </div>
                  </div>
                </div>
                <div className={classes.container146}>
                  <div className={classes.container147}>
                    <div className={classes.container148}>
                      <div className={classes.helloYourdomainCom}>hello@yourdomain.com</div>
                    </div>
                  </div>
                </div>
                <div className={classes.container149}>
                  <div className={classes.container150}>
                    <div className={classes.container151}>
                      <div className={classes.email}>Email :</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.container152}>
              <div className={classes.container153}>
                <div className={classes.container154}>
                  <div className={classes.sVG15}>
                    <div className={classes.uciHiceRiHoiAN5s}>
                      <Ucihicerihoian5sIcon className={classes.icon23} />
                    </div>
                  </div>
                </div>
                <div className={classes.container155}>
                  <div className={classes.container156}>
                    <div className={classes.container157}>
                      <div className={classes.container158}>
                        <div className={classes.a0ce3353befb16cec7fac33d16050d}>
                          <div className={classes.a0ce3353befb16cec7fac33d16050d2}>
                            <div className={classes.a0ce3353befb16cec7fac33d16050d3}>
                              <A0ce3353befb16cec7fac33d16050d className={classes.icon24} />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={classes.container159}>
                  <div className={classes.container160}>
                    <div className={classes.container161}>
                      <div className={classes.container162}>
                        <div className={classes._13f68cc073c04971e2acac869f3ea0}>
                          <div className={classes._13f68cc073c04971e2acac869f3ea02}>
                            <div className={classes._13f68cc073c04971e2acac869f3ea03}>
                              <_13f68cc073c04971e2acac869f3ea0 className={classes.icon25} />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={classes.container163}>
                  <div className={classes.container164}>
                    <div className={classes.container165}>
                      <div className={classes.container166}>
                        <div className={classes._85e1818a3598c721bb9e7b53832406}>
                          <div className={classes._85e1818a3598c721bb9e7b538324062}>
                            <div className={classes._85e1818a3598c721bb9e7b538324063}>
                              <_85e1818a3598c721bb9e7b53832406 className={classes.icon26} />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={classes.container167}>
                  <div className={classes.container168}>
                    <div className={classes.container169}>
                      <div className={classes.socialMedia}>Social Media :</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});
