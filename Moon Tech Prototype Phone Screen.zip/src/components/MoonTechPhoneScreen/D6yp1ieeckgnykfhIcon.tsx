import { memo, SVGProps } from 'react';

const D6yp1ieeckgnykfhIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 364 337' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0H363.98V336.56H0V0Z' fill='#071332' />
  </svg>
);

const Memo = memo(D6yp1ieeckgnykfhIcon);
export { Memo as D6yp1ieeckgnykfhIcon };
