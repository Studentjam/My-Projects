import { memo, SVGProps } from 'react';

const Fzwkq74mgsnkjjlsIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 364 139' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0H364V138.8H0V0Z' fill='white' />
  </svg>
);

const Memo = memo(Fzwkq74mgsnkjjlsIcon);
export { Memo as Fzwkq74mgsnkjjlsIcon };
