import { memo, SVGProps } from 'react';

const Darmmt8xebsbmk50Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 364 128' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0H364V127.531H0V0Z' fill='#E6CF57' />
  </svg>
);

const Memo = memo(Darmmt8xebsbmk50Icon);
export { Memo as Darmmt8xebsbmk50Icon };
