import { memo, SVGProps } from 'react';

const Ellipse7Icon3 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 48 47' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={24} cy={23.8701} rx={24} ry={23} fill='#E6CF57' />
  </svg>
);

const Memo = memo(Ellipse7Icon3);
export { Memo as Ellipse7Icon3 };
