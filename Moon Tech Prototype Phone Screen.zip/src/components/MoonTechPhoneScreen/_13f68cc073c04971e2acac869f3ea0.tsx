import { memo, SVGProps } from 'react';

const _13f68cc073c04971e2acac869f3ea0 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 48 48' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_112_364)'>
      <path
        d='M26.02 16.62V20.48H30.88L30.2 25.76H26.02V37.86H20.72V25.76H16.18V20.48H20.72V16.62C20.72 12.44 24.1 9.62 28.28 9.62C30.12 9.62 31.28 9.9 31.28 9.9V14.36H28.28C27.04 14.36 26.02 15.38 26.02 16.62Z'
        fill='#E6CF57'
      />
      <path
        d='M23.74 47.48C10.66 47.48 0 36.84 0 23.74C0 10.64 10.66 0 23.74 0C36.84 0 47.48 10.66 47.48 23.74C47.48 36.82 36.84 47.48 23.74 47.48ZM23.74 1.3C11.36 1.3 1.3 11.36 1.3 23.74C1.3 36.12 11.36 46.18 23.74 46.18C36.12 46.18 46.18 36.12 46.18 23.74C46.18 11.36 36.12 1.3 23.74 1.3Z'
        fill='#E6CF57'
      />
    </g>
    <defs>
      <clipPath id='clip0_112_364'>
        <rect width={47.48} height={47.48} fill='white' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(_13f68cc073c04971e2acac869f3ea0);
export { Memo as _13f68cc073c04971e2acac869f3ea0 };
