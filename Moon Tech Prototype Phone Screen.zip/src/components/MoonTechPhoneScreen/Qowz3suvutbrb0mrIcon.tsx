import { memo, SVGProps } from 'react';

const Qowz3suvutbrb0mrIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 98 19' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M9.42433 -1.04868e-07H88.0156C93.202 -1.04868e-07 97.4065 4.20406 97.4065 9.39002C97.4065 14.576 93.202 18.78 88.0156 18.78H9.42433C4.2379 18.78 0.0334677 14.576 0.0334677 9.39002C0.0334677 4.20406 4.2379 -1.04868e-07 9.42433 -1.04868e-07Z'
      fill='#E6CF57'
    />
  </svg>
);

const Memo = memo(Qowz3suvutbrb0mrIcon);
export { Memo as Qowz3suvutbrb0mrIcon };
