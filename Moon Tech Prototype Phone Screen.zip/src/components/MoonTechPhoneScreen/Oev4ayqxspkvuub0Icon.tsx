import { memo, SVGProps } from 'react';

const Oev4ayqxspkvuub0Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 364 294' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0H363.97V293.39H0V0Z' fill='#0A1A44' />
  </svg>
);

const Memo = memo(Oev4ayqxspkvuub0Icon);
export { Memo as Oev4ayqxspkvuub0Icon };
