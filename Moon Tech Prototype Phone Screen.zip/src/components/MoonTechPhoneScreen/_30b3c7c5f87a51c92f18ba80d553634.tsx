import { memo, SVGProps } from 'react';

const _30b3c7c5f87a51c92f18ba80d553634 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 25 21' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_112_338)'>
      <path
        d='M0 11.8029C0 4.68209 3.69497 0.987115 10.8157 0.987115V6.11358C7.96499 6.11358 6.09303 7.31261 5.40787 9.52715H10.8157V20.3429H0V11.8029ZM13.6543 11.8029C13.6543 4.68209 17.3615 0.987115 24.47 0.987115V6.11358C21.6192 6.11358 19.7473 7.31261 19.0621 9.52715H24.47V20.3429H13.6543V11.8029Z'
        fill='white'
      />
    </g>
    <defs>
      <clipPath id='clip0_112_338'>
        <rect width={24.47} height={19.3558} fill='white' transform='translate(0 0.987115)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(_30b3c7c5f87a51c92f18ba80d553634);
export { Memo as _30b3c7c5f87a51c92f18ba80d553634 };
