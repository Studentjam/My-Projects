import { memo, SVGProps } from 'react';

const C2de55dd86a7cf0b41fbce097e3a24 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 570 322' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_112_288)'>
      <path
        fillRule='evenodd'
        clipRule='evenodd'
        d='M0 0.799375H569.3V321.031H0V0.799375Z'
        fill='url(#paint0_linear_112_288)'
      />
    </g>
    <defs>
      <linearGradient
        id='paint0_linear_112_288'
        x1={0}
        y1={0.799375}
        x2={27366.9}
        y2={48653.1}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#235A86' />
        <stop offset={1} />
      </linearGradient>
      <clipPath id='clip0_112_288'>
        <rect width={569.3} height={320.231} fill='white' transform='translate(0 0.799375)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(C2de55dd86a7cf0b41fbce097e3a24);
export { Memo as C2de55dd86a7cf0b41fbce097e3a24 };
