import { memo, SVGProps } from 'react';

const _30b3c7c5f87a51c92f18ba80d553633 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 25 21' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_112_334)'>
      <path
        d='M0 11.8033C0 4.67964 3.69648 0.98316 10.8202 0.98316V6.11172C7.96824 6.11172 6.09552 7.31124 5.41008 9.52668H10.8202V20.3468H0V11.8033ZM13.6598 11.8033C13.6598 4.67964 17.3686 0.98316 24.48 0.98316V6.11172C21.6281 6.11172 19.7554 7.31124 19.0699 9.52668H24.48V20.3468H13.6598V11.8033Z'
        fill='white'
      />
    </g>
    <defs>
      <clipPath id='clip0_112_334'>
        <rect width={24.48} height={19.3637} fill='white' transform='translate(0 0.98316)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(_30b3c7c5f87a51c92f18ba80d553633);
export { Memo as _30b3c7c5f87a51c92f18ba80d553633 };
