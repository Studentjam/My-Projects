import { memo, SVGProps } from 'react';

const Ucihicerihoian5sIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 364 143' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0H363.94V142.42H0V0Z' fill='#071332' />
  </svg>
);

const Memo = memo(Ucihicerihoian5sIcon);
export { Memo as Ucihicerihoian5sIcon };
