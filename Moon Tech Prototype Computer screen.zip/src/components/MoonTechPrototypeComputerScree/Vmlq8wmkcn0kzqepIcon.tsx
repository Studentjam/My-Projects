import { memo, SVGProps } from 'react';

const Vmlq8wmkcn0kzqepIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 60 60' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M29.6 0C13.2524 0 0 13.2568 0 29.61C0 45.9632 13.2524 59.22 29.6 59.22C45.9476 59.22 59.2 45.9632 59.2 29.61C59.2 13.2568 45.9476 0 29.6 0Z'
      fill='#E6CF57'
    />
  </svg>
);

const Memo = memo(Vmlq8wmkcn0kzqepIcon);
export { Memo as Vmlq8wmkcn0kzqepIcon };
