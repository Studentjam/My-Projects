import { memo, SVGProps } from 'react';

const Ut3w0ixiwojsr7lwIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 456 384' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0H455.3V383.81H0V0Z' fill='#0A1A44' />
  </svg>
);

const Memo = memo(Ut3w0ixiwojsr7lwIcon);
export { Memo as Ut3w0ixiwojsr7lwIcon };
