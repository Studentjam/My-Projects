import { memo, SVGProps } from 'react';

const Qowz3suvutbrb0mrIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 341 66' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M32.849 6.2561e-07H307.651C325.786 6.2561e-07 340.487 14.7008 340.487 32.8351C340.487 50.9694 325.786 65.6701 307.651 65.6701H32.849C14.7142 65.6701 0.0130134 50.9694 0.0130134 32.8351C0.0130134 14.7008 14.7142 6.2561e-07 32.849 6.2561e-07Z'
      fill='#E6CF57'
    />
  </svg>
);

const Memo = memo(Qowz3suvutbrb0mrIcon);
export { Memo as Qowz3suvutbrb0mrIcon };
