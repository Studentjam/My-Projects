import { memo, SVGProps } from 'react';

const Ellipse3Icon3 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 63 63' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <circle cx={31.36} cy={31.8101} r={31} fill='#E6CF57' />
  </svg>
);

const Memo = memo(Ellipse3Icon3);
export { Memo as Ellipse3Icon3 };
