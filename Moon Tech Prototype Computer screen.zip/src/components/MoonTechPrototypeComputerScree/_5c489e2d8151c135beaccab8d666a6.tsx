import { memo, SVGProps } from 'react';

const _5c489e2d8151c135beaccab8d666a6 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1442 812' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_112_147)'>
      <path
        fillRule='evenodd'
        clipRule='evenodd'
        d='M0 0.700312H1441.03V811.28H0V0.700312Z'
        fill='url(#paint0_linear_112_147)'
      />
    </g>
    <defs>
      <linearGradient
        id='paint0_linear_112_147'
        x1={0}
        y1={0.700312}
        x2={69272.1}
        y2={123151}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#235A86' />
        <stop offset={1} stopColor='#071332' />
      </linearGradient>
      <clipPath id='clip0_112_147'>
        <rect width={1441.03} height={810.579} fill='white' transform='translate(0 0.700312)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(_5c489e2d8151c135beaccab8d666a6);
export { Memo as _5c489e2d8151c135beaccab8d666a6 };
