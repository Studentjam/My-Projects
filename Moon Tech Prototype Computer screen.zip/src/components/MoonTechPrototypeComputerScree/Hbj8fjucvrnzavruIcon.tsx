import { memo, SVGProps } from 'react';

const Hbj8fjucvrnzavruIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 552 147' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0H551.91V146.88H0V0Z' fill='#E6CF57' />
  </svg>
);

const Memo = memo(Hbj8fjucvrnzavruIcon);
export { Memo as Hbj8fjucvrnzavruIcon };
