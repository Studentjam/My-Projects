import { memo, SVGProps } from 'react';

const DqaxsiqoxaknkbbfIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 552 147' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0H551.92V146.88H0V0Z' fill='white' />
  </svg>
);

const Memo = memo(DqaxsiqoxaknkbbfIcon);
export { Memo as DqaxsiqoxaknkbbfIcon };
