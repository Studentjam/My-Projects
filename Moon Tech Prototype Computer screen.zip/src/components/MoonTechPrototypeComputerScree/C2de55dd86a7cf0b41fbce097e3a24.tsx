import { memo, SVGProps } from 'react';

const C2de55dd86a7cf0b41fbce097e3a24 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1470 828' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_112_114)'>
      <path
        fillRule='evenodd'
        clipRule='evenodd'
        d='M0 0.72625H1469.56V827.354H0V0.72625Z'
        fill='url(#paint0_linear_112_114)'
      />
    </g>
    <defs>
      <linearGradient
        id='paint0_linear_112_114'
        x1={0}
        y1={0.72625}
        x2={70643.5}
        y2={125589}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#235A86' />
        <stop offset={1} />
      </linearGradient>
      <clipPath id='clip0_112_114'>
        <rect width={1469.56} height={826.628} fill='white' transform='translate(0 0.72625)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(C2de55dd86a7cf0b41fbce097e3a24);
export { Memo as C2de55dd86a7cf0b41fbce097e3a24 };
