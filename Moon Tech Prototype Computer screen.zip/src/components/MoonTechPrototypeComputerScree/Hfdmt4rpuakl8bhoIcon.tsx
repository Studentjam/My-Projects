import { memo, SVGProps } from 'react';

const Hfdmt4rpuakl8bhoIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 552 147' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M0 0H551.88V146.88H0V0Z' fill='#071332' />
  </svg>
);

const Memo = memo(Hfdmt4rpuakl8bhoIcon);
export { Memo as Hfdmt4rpuakl8bhoIcon };
